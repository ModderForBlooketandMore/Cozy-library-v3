--!strict
-- Place this LocalScript in StarterPlayerScripts for a quick test.
-- Require path may differ depending on how you organize the ModuleScript in Studio.

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Splash = require(ReplicatedStorage:WaitForChild("CozyV3"):WaitForChild("Core"):WaitForChild("Splash"))

local loading = Splash.new({
	Title = "Cozy V3",
	Subtitle = "A calmer way to configure your experience",
	-- Replace this later if you want to use an uploaded ImageLabel asset.
	Accent = Color3.fromRGB(177, 119, 255),
	Background = Color3.fromRGB(12, 10, 20),
})

loading:Build()
loading:Run({
	{Name = "Warming the coffee...", Duration = 0.35},
	{Name = "Loading Cozy theme...", Duration = 0.35},
	{Name = "Preparing the interface...", Duration = 0.45},
	{Name = "Connecting components...", Duration = 0.35},
	{Name = "Finishing setup...", Duration = 0.3},
}, function()
	-- Create the rest of your V3 UI here.
	task.wait(0.15)
	loading:Close()
end)
