# Cozy Library V3

A clean Roblox Luau starter for the Cozy V3 interface library.

## Included

- Full-screen Cozy splash screen with a purple steaming coffee-cup logo
- Animated progress and real initialization statuses
- Custom UI title and `Cozy Library V3` credit line
- Game detection by `GameId`
- Purple wrong-game notification
- `AddTab()` for custom tabs
- Home, Chat, Tools, and bottom-pinned Settings tabs
- Ten base settings plus UI colour and UI transparency controls
- Draggable window using the Cozy title bar
- Animated left-side tab rail: collapsed icons expand to labels on hover
- Touch/mobile mode: all tab labels remain visible together
- Settings toggle for animated side tabs
- Shrink/expand profile mode
- Responsive-safe `UIScale` foundation
- Named loading overlay action through `AddScriptStartPlay()`
- Safe `AddTool()` callbacks for explicitly registered client actions
- Small read-only `CozyDex` badge in Home
- Live `CordPos` display for the local player
- Default, Hacker, Dev, and GameID visual background modes
- Optional developer-provided custom background asset

## Basic setup

```lua
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Library = require(
    ReplicatedStorage:WaitForChild("CozyV3"):WaitForChild("Core"):WaitForChild("Library")
)

local Cozy = Library.new({
    Name = "My Cozy UI",
    GameId = 123456789,
    GameName = "My Game",
    Accent = Color3.fromRGB(177, 119, 255),
    DefaultTransparency = 0.15,
    Background = "Default", -- "Hacker", "Dev", or "GameID" are also supported
})

Cozy:AddTab({
    Name = "My Tab",
    Icon = "★",
})

Cozy:AddScriptStartPlay("Start Animation", "CozyAnimationInject", function()
    print("The visual loading animation finished")
end)
```

## Dragging and side tabs

- Drag the window from the title bar.
- On desktop, move the pointer over the left tab rail to reveal labels.
- Move away to collapse it back to compact icons.
- On touch devices, the rail stays expanded so all tabs are easy to reach.
- The Settings tab includes `Animated side tabs`, which can disable the reveal animation and keep the rail expanded.

The public control is also available:

```lua
Cozy:SetSideRailAnimation(true)
```

## Home and CozyDex

Home contains a small `CozyDex` label and a read-only information card showing the local player's name and live coordinates:

```text
CozyDex  •  read-only
Player: Username
CordPos: X 0.0  Y 5.0  Z 0.0
```

This is a developer/UI information panel. It does not inspect arbitrary games, scan vulnerabilities, execute source, or bypass permissions.

## Appearance controls

The constructor accepts:

```lua
DefaultTransparency = 0.15
Background = "Default"
```

The transparency value is clamped between `0` and `1`. For example, `0.15` means 15% transparent. Background options are:

- `"Default"` — Cozy's dark purple background
- `"Hacker"` — green-on-black visual theme only
- `"Dev"` — blue developer theme
- `"GameID"` — deterministic colour based on the current game ID

For an asset owned and approved by the developer, use:

```lua
Cozy:SetCustomBackgroundAsset("rbxassetid://123456789")
```

## Safe boundary

This project intentionally does **not** include anti-detection behavior, bypasses, exploit functionality, arbitrary source execution, vulnerability scanning, credential collection, or chat-filter bypasses. The UI is created in `PlayerGui`, which is the appropriate container for a normal Roblox experience.

`AddTool()` only runs callbacks that the developer explicitly registers in the source. The loading action is a visual overlay; it does not inject or execute arbitrary scripts.

## Import into Roblox Studio

1. Create a `Folder` named `CozyV3` in `ReplicatedStorage`.
2. Create a `Folder` named `Core` inside it.
3. Add `Core/Splash.lua` and `Core/Library.lua` as ModuleScripts.
4. Put the demo LocalScript in `StarterPlayer > StarterPlayerScripts`.
5. Adjust the require paths if you use a different folder layout.

## GitHub

The source is plain Luau and can be uploaded to any GitHub repository. The ZIP package is ready for upload or extraction.

```bash
git init
git add .
git commit -m "Add Cozy Library V3 client UI core"
git branch -M main
git remote add origin https://github.com/YOUR_NAME/YOUR_REPO.git
git push -u origin main
```

## Next safe milestones

1. Add the Home avatar `ViewportFrame`.
2. Add mobile/desktop layout presets.
3. Add a custom chat panel backed by `TextChatService`.
4. Add server-authoritative playtime statistics if this is for an experience you own.
5. Add a documented settings persistence layer.

## Optional tamper monitor

For a UI running in your own experience, you can enable a best-effort local integrity monitor:

```lua
local Cozy = Library.new({
    Name = "My Cozy UI",
    AntiTamper = true,
    TamperCallback = function(reason)
        warn("Cozy UI integrity notice:", reason)
    end,
})
```

It checks the `ScreenGui` name, an integrity attribute, the root UI, the tab rail, and whether the UI was accidentally reparented. It can restore the expected `PlayerGui` parent and report the reason through `TamperCallback`.

This is not a security boundary. A client that can modify client code can also disable client-side checks. Keep admin permissions, secrets, keys, and privileged actions on the server.
