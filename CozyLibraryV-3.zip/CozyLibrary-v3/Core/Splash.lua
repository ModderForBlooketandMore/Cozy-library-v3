--!strict
-- Cozy V3 - Full-screen branded loading splash
-- Roblox Luau ModuleScript

local TweenService = game:GetService("TweenService")
local Players = game:GetService("Players")

local Splash = {}
Splash.__index = Splash

export type SplashOptions = {
	Title: string?,
	Subtitle: string?,
	Accent: Color3?,
	Background: Color3?,
	Duration: number?,
	LogoImage: string?,
}

local DEFAULTS: SplashOptions = {
	Title = "Cozy V3",
	Subtitle = "Preparing your experience",
	Accent = Color3.fromRGB(177, 119, 255),
	Background = Color3.fromRGB(12, 10, 20),
	Duration = 0.85,
	LogoImage = "",
}

local function mergeOptions(options: SplashOptions?): SplashOptions
	local result = {}
	for key, value in pairs(DEFAULTS) do
		(result :: any)[key] = value
	end
	if options then
		for key, value in pairs(options) do
			(result :: any)[key] = value
		end
	end
	return result
end

local function create(className: string, properties: {[string]: any}, parent: Instance?): Instance
	local object = Instance.new(className)
	for property, value in pairs(properties) do
		(object :: any)[property] = value
	end
	if parent then
		object.Parent = parent
	end
	return object
end

local function tween(instance: Instance, info: TweenInfo, properties: {[string]: any})
	local animation = TweenService:Create(instance, info, properties)
	animation:Play()
	return animation
end

local function addCorner(parent: Instance, radius: number)
	create("UICorner", {CornerRadius = UDim.new(0, radius)}, parent)
end

local function addStroke(parent: Instance, color: Color3, transparency: number, thickness: number)
	create("UIStroke", {
		Color = color,
		Transparency = transparency,
		Thickness = thickness,
		ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
	}, parent)
end

function Splash.new(options: SplashOptions?)
	local self = setmetatable({}, Splash)
	self.Options = mergeOptions(options)
	self.Destroyed = false
	self.Gui = nil
	self.StatusLabel = nil
	self.ProgressFill = nil
	self.ProgressValue = 0
	return self
end

function Splash:_makeSteam(parent: Instance, x: number, delay: number)
	local steam = create("Frame", {
		Name = "Steam",
		AnchorPoint = Vector2.new(0.5, 1),
		Position = UDim2.new(0, x, 0, 70),
		Size = UDim2.fromOffset(4, 30),
		BackgroundColor3 = Color3.fromRGB(238, 222, 255),
		BackgroundTransparency = 0.25,
		Rotation = -8,
	}, parent)
	addCorner(steam, 4)

	task.delay(delay, function()
		if self.Destroyed or not steam.Parent then return end
		while not self.Destroyed and steam.Parent do
			steam.Position = UDim2.new(0, x, 0, 70)
			steam.Size = UDim2.fromOffset(4, 26)
			steam.BackgroundTransparency = 0.25
			steam.Rotation = -8
			tween(steam, TweenInfo.new(1.35, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
				Position = UDim2.new(0, x + 7, 0, 8),
				Size = UDim2.fromOffset(3, 38),
				BackgroundTransparency = 1,
				Rotation = 12,
			})
			task.wait(1.1)
		end
	end)
end

function Splash:_buildLogo(parent: Instance)
	local accent = self.Options.Accent :: Color3
	local logo = create("Frame", {
		Name = "CozyLogo",
		AnchorPoint = Vector2.new(0.5, 0.5),
		Position = UDim2.fromScale(0.5, 0.36),
		Size = UDim2.fromOffset(220, 150),
		BackgroundTransparency = 1,
	}, parent)

	local glow = create("Frame", {
		Name = "Glow",
		AnchorPoint = Vector2.new(0.5, 0.5),
		Position = UDim2.fromScale(0.5, 0.56),
		Size = UDim2.fromOffset(150, 85),
		BackgroundColor3 = accent,
		BackgroundTransparency = 0.82,
	}, logo)
	addCorner(glow, 42)

	local steamLayer = create("Frame", {
		Name = "SteamLayer",
		Position = UDim2.fromOffset(65, 5),
		Size = UDim2.fromOffset(90, 75),
		BackgroundTransparency = 1,
	}, logo)
	self:_makeSteam(steamLayer, 20, 0)
	self:_makeSteam(steamLayer, 45, 0.35)
	self:_makeSteam(steamLayer, 68, 0.7)

	local cup = create("Frame", {
		Name = "Cup",
		AnchorPoint = Vector2.new(0.5, 0),
		Position = UDim2.new(0.5, -8, 0, 58),
		Size = UDim2.fromOffset(112, 62),
		BackgroundColor3 = accent,
	}, logo)
	addCorner(cup, 16)
	addStroke(cup, Color3.fromRGB(230, 205, 255), 0.45, 2)

	local coffee = create("Frame", {
		Name = "Coffee",
		AnchorPoint = Vector2.new(0.5, 0),
		Position = UDim2.new(0.5, 0, 0, 5),
		Size = UDim2.fromOffset(86, 13),
		BackgroundColor3 = Color3.fromRGB(62, 35, 76),
	}, cup)
	addCorner(coffee, 8)

	local handle = create("Frame", {
		Name = "Handle",
		Position = UDim2.new(1, -4, 0, 14),
		Size = UDim2.fromOffset(30, 30),
		BackgroundColor3 = accent,
	}, cup)
	addCorner(handle, 15)
	local handleHole = create("Frame", {
		Name = "HandleHole",
		Position = UDim2.fromOffset(7, 7),
		Size = UDim2.fromOffset(16, 16),
		BackgroundColor3 = self.Options.Background :: Color3,
	}, handle)
	addCorner(handleHole, 9)

	local wordmark = create("TextLabel", {
		Name = "Wordmark",
		AnchorPoint = Vector2.new(0.5, 0),
		Position = UDim2.new(0.5, 0, 0, 78),
		Size = UDim2.fromOffset(100, 30),
		BackgroundTransparency = 1,
		Text = "Cozy",
		TextColor3 = Color3.fromRGB(255, 247, 255),
		TextSize = 22,
		Font = Enum.Font.GothamBold,
		TextXAlignment = Enum.TextXAlignment.Center,
	}, logo)

	return logo
end

function Splash:_setProgress(value: number, status: string)
	self.ProgressValue = math.clamp(value, 0, 1)
	if self.ProgressFill then
		tween(self.ProgressFill, TweenInfo.new(0.28, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), {
			Size = UDim2.new(self.ProgressValue, 0, 1, 0),
		})
	end
	if self.StatusLabel then
		self.StatusLabel.Text = status
	end
end

function Splash:Build()
	local player = Players.LocalPlayer
	assert(player, "Cozy V3 Splash must run on the client")

	local playerGui = player:WaitForChild("PlayerGui")
	local gui = create("ScreenGui", {
		Name = "CozyV3Splash",
		IgnoreGuiInset = true,
		ResetOnSpawn = false,
		DisplayOrder = 10000,
		ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
	}, playerGui)
	self.Gui = gui

	local background = create("Frame", {
		Name = "Background",
		Size = UDim2.fromScale(1, 1),
		BackgroundColor3 = self.Options.Background :: Color3,
		BackgroundTransparency = 0,
	}, gui)

	local gradient = create("UIGradient", {
		Color = ColorSequence.new({
			ColorSequenceKeypoint.new(0, self.Options.Background :: Color3),
			ColorSequenceKeypoint.new(1, Color3.fromRGB(25, 16, 39)),
		}),
		Rotation = 125,
	}, background)

	local vignette = create("Frame", {
		Name = "Vignette",
		Size = UDim2.fromScale(1, 1),
		BackgroundColor3 = Color3.fromRGB(0, 0, 0),
		BackgroundTransparency = 0.82,
	}, background)

	local content = create("Frame", {
		Name = "Content",
		AnchorPoint = Vector2.new(0.5, 0.5),
		Position = UDim2.fromScale(0.5, 0.5),
		Size = UDim2.fromOffset(430, 320),
		BackgroundTransparency = 1,
	}, background)

	local logo = self:_buildLogo(content)
	local title = create("TextLabel", {
		Name = "Title",
		AnchorPoint = Vector2.new(0.5, 0),
		Position = UDim2.fromScale(0.5, 0.58),
		Size = UDim2.fromOffset(380, 40),
		BackgroundTransparency = 1,
		Text = self.Options.Title :: string,
		TextColor3 = Color3.fromRGB(255, 255, 255),
		TextSize = 28,
		Font = Enum.Font.GothamBold,
		TextXAlignment = Enum.TextXAlignment.Center,
	}, content)

	local subtitle = create("TextLabel", {
		Name = "Subtitle",
		AnchorPoint = Vector2.new(0.5, 0),
		Position = UDim2.fromScale(0.5, 0.705),
		Size = UDim2.fromOffset(380, 25),
		BackgroundTransparency = 1,
		Text = self.Options.Subtitle :: string,
		TextColor3 = Color3.fromRGB(190, 180, 204),
		TextSize = 14,
		Font = Enum.Font.Gotham,
		TextXAlignment = Enum.TextXAlignment.Center,
	}, content)

	local track = create("Frame", {
		Name = "ProgressTrack",
		AnchorPoint = Vector2.new(0.5, 0),
		Position = UDim2.fromScale(0.5, 0.82),
		Size = UDim2.fromOffset(330, 7),
		BackgroundColor3 = Color3.fromRGB(55, 43, 66),
	}, content)
	addCorner(track, 4)

	self.ProgressFill = create("Frame", {
		Name = "ProgressFill",
		Size = UDim2.new(0, 0, 1, 0),
		BackgroundColor3 = self.Options.Accent :: Color3,
	}, track)
	addCorner(self.ProgressFill, 4)

	self.StatusLabel = create("TextLabel", {
		Name = "Status",
		AnchorPoint = Vector2.new(0.5, 0),
		Position = UDim2.fromScale(0.5, 0.865),
		Size = UDim2.fromOffset(380, 22),
		BackgroundTransparency = 1,
		Text = "Starting...",
		TextColor3 = Color3.fromRGB(174, 162, 188),
		TextSize = 12,
		Font = Enum.Font.Gotham,
		TextXAlignment = Enum.TextXAlignment.Center,
	}, content)

	-- Entrance animation: fade in the full-screen layer and gently scale the logo.
	background.BackgroundTransparency = 1
	logo.Size = UDim2.fromOffset(190, 130)
	tween(background, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {BackgroundTransparency = 0})
	tween(logo, TweenInfo.new(0.65, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {Size = UDim2.fromOffset(220, 150)})

	return self
end

function Splash:Run(stages: {{Name: string, Duration: number?}}?, onComplete: (() -> ())?)
	if not self.Gui then self:Build() end
	local selectedStages = stages or {
		{Name = "Creating interface...", Duration = 0.35},
		{Name = "Loading theme engine...", Duration = 0.3},
		{Name = "Registering components...", Duration = 0.35},
		{Name = "Preparing configuration...", Duration = 0.3},
		{Name = "Almost ready...", Duration = 0.25},
	}

	local total = #selectedStages
	for index, stage in ipairs(selectedStages) do
		if self.Destroyed then return end
		self:_setProgress((index - 1) / total, stage.Name)
		task.wait(stage.Duration or 0.25)
		self:_setProgress(index / total, stage.Name)
	end

	self:_setProgress(1, "Ready")
	task.wait(0.22)
	if onComplete then onComplete() end
end

function Splash:Close()
	if self.Destroyed then return end
	self.Destroyed = true
	if self.Gui then
		local background = self.Gui:FindFirstChild("Background")
		if background then
			tween(background, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				BackgroundTransparency = 1,
			})
			task.delay(0.38, function()
				if self.Gui then self.Gui:Destroy() end
			end)
		else
			self.Gui:Destroy()
		end
	end
end

function Splash:Destroy()
	self:Close()
end

return Splash
